#include <iostream>
#include "MainClass.h"
using namespace std;

int main()
{
	MainClass main = MainClass();
	system("pause");
	return 0;
}