#include "Stockpile.h"



Stockpile::Stockpile()
{
}


Stockpile::~Stockpile()
{
}
