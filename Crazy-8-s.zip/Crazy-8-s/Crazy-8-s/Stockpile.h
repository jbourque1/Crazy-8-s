#pragma once
class Stockpile
{
public:
	Stockpile();
	~Stockpile();
};

