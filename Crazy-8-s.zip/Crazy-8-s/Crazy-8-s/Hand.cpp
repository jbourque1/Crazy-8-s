#include "Hand.h"



Hand::Hand()
{
}


Hand::~Hand()
{
}