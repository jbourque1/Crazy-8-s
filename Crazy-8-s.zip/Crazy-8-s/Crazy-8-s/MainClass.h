#pragma once
#include <iostream>
#include <thread>
#include <chrono>
#include <conio.h>
#include "Deck.h"
#include "Hand.h"
#include "Player.h"
#include "Card.h"
#include "MainClass.h"
#include <string>
using namespace std;

class MainClass
{
public:
	MainClass();
	~MainClass();
};

